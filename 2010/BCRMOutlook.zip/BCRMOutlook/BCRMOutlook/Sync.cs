﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BCRMOutlook
{
	public partial class Sync : Form
	{
		public Sync()
		{
			InitializeComponent();
		}

		private void Sync_Load(object sender, EventArgs e)
		{

		}

		private void lblSync_Click(object sender, EventArgs e)
		{

		}

		private void btnOk_Click(object sender, EventArgs e)
		{
			this.Dispose();
			this.Close();
		}

		private void tbSync_TextChanged(object sender, EventArgs e)
		{

		}

	}
}
